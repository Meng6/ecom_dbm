#!/usr/bin/env python
# encoding: utf-8

from django.conf.urls import url
from ecom.apps.account import views

urlpatterns = [
    url(r'^signin/$', views.signin, name='signin'),
    url(r'^signup/$', views.signup, name='signup'),
    url(r'^userinfo/$', views.userinfo, name='userinfo'),
]
