# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Address',
            fields=[
                ('aid', models.AutoField(primary_key=True, serialize=False, auto_created=True)),
                ('steet', models.CharField(max_length=100)),
                ('city', models.CharField(max_length=100)),
                ('state', models.CharField(max_length=2, help_text='Use the state abbreviation, such as PA')),
                ('zipCode', models.CharField(max_length=5)),
            ],
            options={
                'verbose_name_plural': 'Addresses',
                'db_table': 'addresses',
                'ordering': ('aid',),
            },
        ),
        migrations.CreateModel(
            name='Business',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('busicate', models.CharField(max_length=50)),
                ('gaincome', models.DecimalField(max_digits=10, decimal_places=2)),
            ],
            options={
                'verbose_name_plural': 'Businesses',
                'db_table': 'business',
                'ordering': ('cid',),
            },
        ),
        migrations.CreateModel(
            name='Customer',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('cname', models.CharField(max_length=50, db_index=True)),
                ('slug', models.SlugField(verbose_name='Slug', unique=True, help_text='根据name生成的，用于生成页面URL，必须唯一')),
                ('kind', models.BooleanField(default=False)),
                ('email', models.EmailField(max_length=254)),
                ('phone', models.CharField(max_length=13, help_text='The format should be like (xxx)xxx-xxxx')),
                ('aid', models.ForeignKey(to='account.Address')),
                ('cid', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
                'verbose_name_plural': 'Customers',
                'db_table': 'customers',
                'ordering': ('cname',),
            },
        ),
        migrations.CreateModel(
            name='Home',
            fields=[
                ('id', models.AutoField(verbose_name='ID', primary_key=True, serialize=False, auto_created=True)),
                ('mgrstatus', models.BooleanField(default=False)),
                ('gender', models.BooleanField()),
                ('age', models.PositiveIntegerField()),
                ('income', models.DecimalField(max_digits=10, decimal_places=2)),
                ('cid', models.OneToOneField(to='account.Customer')),
            ],
            options={
                'verbose_name_plural': 'Home',
                'db_table': 'home',
                'ordering': ('cid',),
            },
        ),
        migrations.AddField(
            model_name='business',
            name='cid',
            field=models.OneToOneField(to='account.Customer'),
        ),
    ]
