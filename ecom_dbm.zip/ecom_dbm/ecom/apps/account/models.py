#!/usr/bin/env python
# encoding: utf-8

from django.core.urlresolvers import reverse
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver


class Address(models.Model):
    aid = models.AutoField(auto_created=True, primary_key=True)
    steet = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=2, help_text = "Use the state abbreviation, such as PA")
    zipCode = models.CharField(max_length=5)

    class Meta:
        db_table = 'addresses'
        ordering = ('aid',)
        verbose_name_plural = 'Addresses'

    def __str__(self):
        return self.name

class Customer(models.Model):
    cid = models.OneToOneField(User, on_delete=models.CASCADE)
    cname = models.CharField(max_length=50, db_index=True)
    slug = models.SlugField(
        "Slug",
        max_length=50,
        unique=True)

    aid = models.ForeignKey(Address) # to deal with one-to-many relations
    kind = models.BooleanField(default=False) # use false to denote home; true to denote business. here the default value is False
    email = models.EmailField(max_length=254)
    phone = models.CharField(max_length=13, help_text="The format should be like (xxx)xxx-xxxx")

    class Meta:
        db_table = 'customers'
        ordering = ('cname',)
        verbose_name_plural = 'Customers'

    def __str__(self):
        return self.cname

    def get_absolute_url(self):
        return reverse('catalog:product_list_by_category', args=[self.slug])


# @receiver(post_save, sender=User)
# def create_user_customer(sender, instance, created, **kwargs):
#     if created:
#         Profile.objects.create(user=instance)
#
# @receiver(post_save, sender=User)
# def save_user_customer(sender, instance, **kwargs):
#     instance.profile.save()


class Home(models.Model):
    cid = models.OneToOneField(Customer, on_delete=models.CASCADE)
    mgrstatus = models.BooleanField(default=False) # status of marriage, dafault: single
    gender = models.BooleanField() # Female => True; Male => False
    age = models.PositiveIntegerField()
    income = models.DecimalField(max_digits=10, decimal_places=2) # annual income of the coustomer

    class Meta:
        db_table = 'home'
        ordering = ('cid',)
        verbose_name_plural = 'Home'

    def __str__(self):
        return self.name

class Business(models.Model):
    cid = models.OneToOneField(Customer, on_delete=models.CASCADE)
    busicate = models.CharField(max_length=50) # business category
    gaincome = models.DecimalField(max_digits=10, decimal_places=2) # company gross annual income

    class Meta:
        db_table = 'business'
        ordering = ('cid',)
        verbose_name_plural = 'Businesses'

    def __str__(self):
        return self.name
