#!/usr/bin/env python
# encoding: utf-8

from django.http import HttpResponse
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render, redirect
from ecom.apps.account.forms import SigninForm, CustomerForm


def signin(request):
    if request.method == 'POST':
        form = SigninForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(username=cd['username'],
                                password=cd['password'])
            if user is not None:
                if user.is_active:
                    login(request, user)
                    return redirect('/')
                else:
                    return HttpResponse('Disabled account')
            else:
                return HttpResponse('Invalid login')
    else:
        form = SigninForm()
    return render(request, 'account/signin.html', {'form': form})


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            login(request, user)
            return redirect('/account/userinfo')
    else:
        form = UserCreationForm()
    return render(request, 'account/signup.html', {'form': form})


# @login_required
# @transaction.atomic
# def update_customer(request):
#     if request.method == 'POST':
#         user_form = UserForm(request.POST, instance=request.user)
#         customer_form = CustomerForm(request.POST, instance=request.user.customer)
#         if user_form.is_valid() and customer_form.is_valid():
#             user_form.save()
#             customer_form.save()
#             messages.success(request, _('Your profile was successfully updated!'))
#             return redirect('settings:profile')
#         else:
#             messages.error(request, _('Please correct the error below.'))
#     else:
#         user_form = UserForm(instance=request.user)
#         customer_form = customerForm(instance=request.user.customer)
#     return render(request, 'account/Userinfo.html', {
#         'user_form': user_form,
#         'customer_form': profile_form
#     })


def userinfo(request):
    if request.method == 'POST':
        #user = User(request)
        form = CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            cname = form.cleaned_data.get('cname')
            kind = form.cleaned_data.get('kind')
            email = form.cleaned_data.get('email')
            phone = form.cleaned_data.get('phone')
            print(cid)
            return redirect('/')
    else:
        form = CustomerForm()
    return render(request, 'account/Userinfo.html', {'form': form})
